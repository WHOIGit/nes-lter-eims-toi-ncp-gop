See input_corrections.R for data sheets modified with R. 

20230104 Kate Morkeski:

Saved bottleEn661.csv as bottleEn661_original.csv and used R to output new bottleEn661.csv with:
18 duplicated rows removed.
Time corrected from 05-Feb-2021 10:41:00 to 13:08:00 for sample with Niskin 3, depth 140 m. 

20230104 Kate Morkeski:

bottleEn617withoutincubation_corrected.csv additional corrections:

row 59 22-Jul-2018 05:00 changed Niskin from 7 to 17

Changed depth to avoid flagging; depth was initially mis-entered:
row 36 21-Jul-2018 14:51 Niskin 6 -- depth from 34 to 24
row 49 22-Jul-2018 2:08 Niskin 8 -- depth from 50 to 40
row 50 22-Jul-2018 2:08 Niskin 17 -- depth from 28 to 14
row 62 22-Jul-2018 8:58 Niskin 2 -- depth from 0 to 129

20231020 Kate Morkeski:

bottleEn644.csv corrections:

8/21/2019 0:48 depth changed from 2 to 0 (is an underway sample)

8/22/2019  3:10 depth 0 Niskin 17 changed to time = 00:03:10 and depth = 5 (is a surface CTD sample from cast 8)

8/22/2019  3:10 depth 18 Niskin 12 changed to time = 00:03:10 

8/22/2019  3:10 depth 29 Niskin 9 changed to time = 00:03:10

8/22/2019  0:57 depth 32 Niskin 12 changed to time = 04:23 (cast 9)

8/23/2019 16:55 changed time for the three rows with this start time to 21:51 (cast 19)

8/23/2019 23:45 changed date for the two rows with this timestamp (time unchanged) to 8/22/2019 (cast 16)

8/24/2019 23:16 changed date for the two rows with this timestamp (time unchanged) to 8/23/2019 (cast 20)

20230912 Kate Morkeski:

bottleEn617withoutincubation_corrected.csv has 7/24/2018 15:33 corrected from 9 in niskin column to 0 in the niskin column after finding that timepoint on the underway sample log sheets. 

