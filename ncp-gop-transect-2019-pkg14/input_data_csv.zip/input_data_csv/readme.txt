
20231025 Kate Morkeski:

Saved discreteratesEn627_original.csv and  in discreteratesEn627.csv deleted the two rows containing: 
01-Feb-2019 21:39:00, Niskin 2 and 
02-Feb-2019 06:29:00, Niskin 1 since they are not surface


20231020 Kate Morkeski:

discretereatesEn644.csv corrections:

8/21/2019 0:48 depth changed from 2 to 0 (is an underway sample)

8/22/2019  3:10 depth 0 Niskin 17 changed to time = 00:03:10 and depth = 5 (is a surface CTD sample from cast 8)

8/23/2019 16:55 changed time for the one row with this start time to 21:51 (cast 19)

8/23/2019 23:45 changed date for the one row with this timestamp (time unchanged) to 8/22/2019 (cast 16)

8/24/2019 23:45 changed date for the one row with this timestamp (time unchanged) to 8/23/2019 (cast 20)